/*
 * Copyright (C) 2006 Hugo Ruscitti
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdlib.h>
#include "SDL.h"
#include "SDL_image.h"


typedef struct mouse
{
	int x;
	int y;
	int boton;
	SDL_Surface * ima;
	SDL_Surface * bloque;
} Mouse;



SDL_Surface * iniciar_sdl (int w, int h, char * titulo);
void terminar_programa (SDL_Surface * fondo, Mouse * mouse);
int mouse_crear (Mouse * mouse);
void mouse_imprimir (Mouse * mouse, SDL_Surface * screen, SDL_Surface * fondo);
SDL_Surface * crear_fondo (SDL_Surface * screen);
void mouse_pintar_bloque (SDL_Surface * screen, SDL_Surface * fondo, 
		Mouse * mouse);

int main (int argc, char * argv [])
{
	SDL_Surface * screen;
	SDL_Surface * fondo;
	SDL_Event event;
	Mouse mouse;

	screen = iniciar_sdl (640, 480, "Mouse con eventos");

	if (! screen)
		exit (1);

	fondo = crear_fondo (screen);

	if (! fondo)
		exit (1);

	SDL_ShowCursor (SDL_DISABLE);
	
	if (mouse_crear (& mouse))
		exit (1);

	
	/* con `SDL_WaitEvent` se bloquea el programa hasta
	 * que se produce un evento. */
	
	while (SDL_WaitEvent (&event))
	{
		switch (event.type)
		{
			case SDL_QUIT:
				terminar_programa (fondo, & mouse);
				break;

			case SDL_MOUSEMOTION:
				mouse.x = event.motion.x;
				mouse.y = event.motion.y;
				
				mouse_imprimir (& mouse, screen, fondo);
				break;
			
			case SDL_MOUSEBUTTONDOWN:
				
				switch (event.button.button)
				{
					case SDL_BUTTON_LEFT:
						mouse.boton = 1;
						break;

					case SDL_BUTTON_RIGHT:
						mouse.boton = 2;
						break;

					default:
						mouse.boton = -1;
				}

				mouse_imprimir (& mouse, screen, fondo);
				break;
			
			case SDL_MOUSEBUTTONUP:
				mouse.boton = -1;
				break;
				
			default:
				break;
		}
	}

	terminar_programa (fondo, & mouse);
	return 0;
}


void terminar_programa (SDL_Surface * fondo, Mouse * mouse)
{
	SDL_FreeSurface (fondo);
	SDL_FreeSurface (mouse->ima);
	SDL_FreeSurface (mouse->bloque);
	exit (0);
}


int mouse_crear (Mouse * mouse)
{
	mouse->ima = IMG_Load ("../ima/cursor.png");

	if (! mouse->ima)
	{
		printf ("%s\n", SDL_GetError ());
		return 1;
	}

	mouse->bloque = IMG_Load ("../ima/bloque.png");

	if (! mouse->bloque)
	{
		printf ("%s\n", SDL_GetError ());
		return 1;
	}
	
	mouse->boton = -1;

	return 0;
}


void mouse_imprimir (Mouse * mouse, SDL_Surface * screen, SDL_Surface * fondo)
{
	static SDL_Rect rect_anterior = {0, 0, 0, 0};
	SDL_Rect rect;

	rect.x = mouse->x;
	rect.y = mouse->y - 9; /* 9 es el punto de control en y */

	if (mouse->boton != -1)
		mouse_pintar_bloque (screen, fondo, mouse);

	SDL_BlitSurface (mouse->ima, NULL, screen, & rect);

	/* `SDL_BlitSurface` modificar� los valores de `rect` a
	 * fin de especificar que zona de pantalla visible que 
	 * efectivamente se imprimi�. Esto evita que debamos 
	 * controlar el desborde de `rect` en la siguiente 
	 * funci�n */
	
	SDL_UpdateRects (screen, 1, & rect_anterior);
	SDL_UpdateRects (screen, 1, & rect);

	/* Se asegura que en la pr�xima llamada a la funci�n se 
	 * elimine la region modificada */
	
	SDL_BlitSurface (fondo, &rect, screen, &rect);
	rect_anterior = rect;
}


SDL_Surface * crear_fondo (SDL_Surface * screen)
{
	SDL_Surface * tmp;
	Uint32 color = SDL_MapRGB (screen->format, 240, 240, 240);
	
	tmp = SDL_DisplayFormat (screen);

	if (! tmp)
	{
		printf ("%s\n", SDL_GetError ());
		return NULL;
	}

	SDL_FillRect (tmp, NULL, color);
	SDL_BlitSurface (tmp, NULL, screen, NULL);
	SDL_Flip (screen);
	
	return tmp;
}


void mouse_pintar_bloque (SDL_Surface * screen, SDL_Surface * fondo, 
		Mouse * mouse)
{
	Uint32 color = SDL_MapRGB (screen->format, 240, 240, 240);
	SDL_Rect rect;

	/* solo puede imprimir un bloque sobre la grilla de tama�o
	 * uniforme (32x32 pixeles por celda), como si fuera un tablero
	 * de juego de mesa. 
	 *
	 * Por ejemplo, cuando mouse.x tiene un valor como 65 se le quita 
	 * el resto de dividir por 32 y se obtine 64, la coordenada correcta
	 * para imprimir sobre el tablero.
	 */

	rect.x = mouse->x - (mouse->x % 32);
	rect.y = mouse->y - (mouse->y % 32);
	rect.w = mouse->bloque->w;
	rect.h = mouse->bloque->h;

	if (mouse->boton == 1)
	{
		SDL_BlitSurface (mouse->bloque, NULL, fondo, & rect);
		SDL_BlitSurface (mouse->bloque, NULL, screen, & rect);
	}
	else
	{
		SDL_FillRect (fondo, & rect, color);
		SDL_BlitSurface (fondo, & rect, screen, & rect);
	}
	
	SDL_UpdateRect (screen, rect.x, rect.y, rect.w, rect.h);
}


SDL_Surface * iniciar_sdl (int w, int h, char * titulo)
{
	int flags = SDL_SWSURFACE;
	SDL_Surface * screen;

	if (SDL_Init (SDL_INIT_VIDEO) == -1)
	{
		printf ("%s\n", SDL_GetError ());
		return NULL;
	}

	atexit (SDL_Quit);

	SDL_WM_SetCaption (titulo, NULL);
	
	screen = SDL_SetVideoMode (w, h, 16, flags);
	
	if (! screen)
	{
		printf ("%s\n", SDL_GetError ());
		return NULL;
	}
	
	return screen;
}
